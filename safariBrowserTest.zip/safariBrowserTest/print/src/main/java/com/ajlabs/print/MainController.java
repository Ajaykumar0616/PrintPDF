package com.ajlabs.print;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/requests")
public class MainController {

    @Autowired
    private PrintService printService;

    @PostMapping(value = "/print")
    public ResponseEntity print(@RequestBody PrintBean printBean)
    {
        System.out.println(printBean.getAwsUrl());
        printService.printService(printBean.getAwsUrl());
        return new ResponseEntity("done", HttpStatus.OK);
    }
}
