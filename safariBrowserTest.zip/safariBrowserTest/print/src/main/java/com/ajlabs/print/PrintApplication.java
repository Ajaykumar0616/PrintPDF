package com.ajlabs.print;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.spire.pdf.PdfDocument;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.S3Object;

import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.net.URL;
import java.time.Instant;

@SpringBootApplication
public class PrintApplication {

	@Value("${spring.aws.s3.name}")
	private static String bucketName;

	public static void main(String[] args) {
		System.setProperty("java.awt.headless", "false");
		//final AmazonS3 s3 = AmazonS3ClientBuilder.standard().withRegion("us-east-1").build();
		SpringApplication.run(PrintApplication.class, args);
		System.out.println("hello");
		java.util.Date expiration = new java.util.Date();
		long expTimeMillis = Instant.now().toEpochMilli();
		expTimeMillis += 1000 * 60 * 60;
		expiration.setTime(expTimeMillis);
		/*GeneratePresignedUrlRequest generatePresignedUrlRequest =
				new GeneratePresignedUrlRequest("ajay-local-doc-versioning", "00D3t000005ePO0EAM/docid123/printTestDocument.pdf")
						.withMethod(HttpMethod.GET)
						.withExpiration(expiration);
		URL url = s3.generatePresignedUrl(generatePresignedUrlRequest);
		System.out.println("Pre-Signed URL: " + url.toString());*/
		////////////////////////////////////////////////////////////////////////////////////////////








		/*System.setProperty("java.awt.headless", "false");

		String bucketName = "ajay-local-doc-versioning";
		String key = "00D3t000005ePO0EAM/docid123/SYS-XX-101-CX.pdf";

		S3Client client = S3Client.builder().build();

		GetObjectRequest request = GetObjectRequest.builder()
				.bucket(bucketName)
				.key(key)
				.build();

		PrinterJob printerJob = PrinterJob.getPrinterJob();
		PageFormat pageFormat = printerJob.defaultPage();
		Paper paper = pageFormat.getPaper();
		paper.setImageableArea(0,0, pageFormat.getWidth(), pageFormat.getHeight());
		pageFormat.setPaper(paper);
		PdfDocument pdfDocument = new PdfDocument();
		pdfDocument.loadFromBytes(client.getObjectAsBytes(request).asByteArray());*/
		//pdfDocument.loadFromFile("C:\\Users\\H519911\\Downloads\\SYS-XX-101-CX.pdf");
		/*printerJob.setPrintable(pdfDocument, pageFormat);
		if(printerJob.printDialog())
		{
			try{
				printerJob.print();
			}
			catch (PrinterException ex)
			{
				ex.printStackTrace();
			}
		}*/

	}
	/*@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurer() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/requests").allowedOrigins("http://localhost:8080");
			}
		};
	}*/
}
