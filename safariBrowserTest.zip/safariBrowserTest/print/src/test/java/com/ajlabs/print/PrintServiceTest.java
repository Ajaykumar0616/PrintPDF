package com.ajlabs.print;

import org.junit.jupiter.api.Test;

public class PrintServiceTest {

    @Test
    void GetTest()
    {

    }
}
