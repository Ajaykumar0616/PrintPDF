package com.ajlabs.print;

import com.amazonaws.services.s3.AmazonS3URI;
import com.spire.pdf.PdfDocument;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;

import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.net.URI;
import java.net.URISyntaxException;

@Service
public class PrintService {
    @Value("${spring.aws.s3.name}")
    private String bucketName;

    public void printService(String awsUrl)
    {
        System.out.println(awsUrl);
       // S3Client client = S3Client.builder().build();
        PrinterJob printerJob = PrinterJob.getPrinterJob();
        PageFormat pageFormat = printerJob.defaultPage();
        Paper paper = pageFormat.getPaper();
        paper.setImageableArea(0,0, pageFormat.getWidth(), pageFormat.getHeight());
        pageFormat.setPaper(paper);
        PdfDocument pdfDocument = new PdfDocument();
        URI fileToBeDownloaded = null;
        try {
            fileToBeDownloaded = new URI(awsUrl);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
       /* AmazonS3URI s3URI = new AmazonS3URI(fileToBeDownloaded);
        System.out.println(s3URI.getBucket());
        System.out.println(s3URI.getKey());
        GetObjectRequest request = GetObjectRequest.builder()
                .bucket(s3URI.getBucket())
                .key(s3URI.getKey())
                .build();*/
        //pdfDocument.loadFromBytes(client.getObjectAsBytes(request).asByteArray());
        pdfDocument.loadFromFile("C:\\Users\\H519911\\Downloads\\SYS-XX-101-CX.pdf");
		printerJob.setPrintable(pdfDocument, pageFormat);
		if(printerJob.printDialog())
		{
			try{
				printerJob.print();
			}
			catch (PrinterException ex)
			{
				ex.printStackTrace();
			}
		}
    }
}
